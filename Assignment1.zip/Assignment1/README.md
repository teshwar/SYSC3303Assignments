# In this README.md, I will present the files present and how to run it. 

## Open Assignment 1 Folder in IntelliJea:
	In this Assignment we were asked to implement the SandwichMakingChefsProblem also known as the Cigarette Problem.

	Notes: In my code, to make a sandwich: use PeanutButter, Cheese, Bread
	Files: 
	Agent.java :Implement Agent that gives out 2 random ingredients whenever a chef has eaten
	Chef.java: Implement Chef, that is used to create a type of chef to take 2 ingrdients given, make sandiwch, and eats
	Ingredient.enum: Contains all the ingredients required for bread
	SandwichMakingChefsProblem.java: Stimulatge the sandwich problem, by creating three chefs with each specific type, and one agent
	Table.java: table that is shared between agent and 3 chefs

	To run the project: 
	Go to SandwichMakingChefsProblem.java, and run main.
	
## In UML Diagram:
	Find the Sequence Diagram