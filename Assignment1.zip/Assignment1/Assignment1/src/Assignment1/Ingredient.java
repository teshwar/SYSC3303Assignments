package Assignment1;

/**
 * Represents 3 required ingredients for Sandwich
 *
 * @author Teshwar Tarachand 101167556
 * @version 1.0
 */
public enum Ingredient {
    CHEESE,
    BREAD,
    PEANUT_BUTTER
}
